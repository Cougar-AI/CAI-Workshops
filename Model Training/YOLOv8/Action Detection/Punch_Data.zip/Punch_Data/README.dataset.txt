# Punch Detection > 2025-11-09 2:17pm
https://universe.roboflow.com/cougaraiworkshop/punch-detection-4ggzh

Provided by a Roboflow user
License: CC BY 4.0

