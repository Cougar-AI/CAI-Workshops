# MMA Striking > 2023-01-11 10:41am
https://universe.roboflow.com/mma/mma-striking

Provided by a Roboflow user
License: CC BY 4.0

